/*
 * ESP32 PWM SHOWCASE STATION
 * --------------------------
 * One program, four modes, every PWM idea from the lecture:
 *
 *   Mode 1  BREATHING LED  -> fixed frequency, VARYING DUTY (with gamma correction)
 *   Mode 2  POT DIMMER     -> hardware-in-the-loop: ADC -> map() -> constrain() -> PWM
 *   Mode 3  THEREMIN       -> VARYING FREQUENCY, locked 50% duty (buzzer pitch)
 *   Mode 4  SERVO          -> locked 50 Hz, ABSOLUTE PULSE WIDTH (1.0 - 2.0 ms)
 *   Mode 5  SING           -> the buzzer "sings" a custom song, lyrics appear in Serial
 *
 * Press the button to switch modes. A live "PWM dashboard" prints the
 * frequency, resolution, duty cycle and average voltage in the Serial Monitor.
 *
 * Wiring:  LED  -> GPIO18 (through 330 ohm)    Buzzer -> GPIO19
 *          Servo -> GPIO21                      Pot    -> GPIO34
 *          Button -> GPIO4 to GND (internal pull-up)
 */

#include <Arduino.h>

// ---------- Pins ----------
#define LED_PIN     18
#define BUZZER_PIN  19
#define SERVO_PIN   21
#define POT_PIN     34
#define BUTTON_PIN  4

// ---------- LEDC channels ----------
// Channels are paired on timers (0,1)(2,3)(4,5)... Each of our three outputs needs
// a DIFFERENT frequency, so each one gets its own timer: channels 0, 2 and 4.
#define LED_CH      0
#define BUZZER_CH   2
#define SERVO_CH    4

// ---------- PWM settings ----------
const int LED_FREQ  = 5000;                 // 5 kHz, no visible flicker
const int LED_RES   = 10;                   // 10-bit = 1024 levels (smoother than 8-bit)
const int LED_MAX   = (1 << LED_RES) - 1;   // 2^N - 1 = 1023

const int SERVO_FREQ   = 50;                // servos need exactly 50 Hz (20 ms period)
const int SERVO_RES    = 16;                // 16-bit for fine pulse-width control
const int SERVO_MAX    = (1 << SERVO_RES) - 1;
const int SERVO_MIN_US = 1000;              // 1.0 ms = 0 degrees
const int SERVO_MAX_US = 2000;              // 2.0 ms = 180 degrees (use 500/2500 for full range)

// ---------- Modes ----------
enum Mode { BREATHING, DIMMER, THEREMIN, SERVO, SING, NUM_MODES };
const char* modeNames[] = {"BREATHING LED", "POT DIMMER", "THEREMIN", "SERVO", "SING"};
int mode = BREATHING;

// ---------- Button debounce ----------
const unsigned long DEBOUNCE_MS = 50;
int lastReading = HIGH;
int buttonState = HIGH;
unsigned long lastDebounceTime = 0;

// ---------- Potentiometer smoothing ----------
float smoothPot = 0;

// ---------- Values shown on the dashboard ----------
int  curFreq = 0, curBits = 0, curDuty = 0, curMax = 1;
int  curPulseUs = 0, curAngle = 0;
unsigned long lastPrint = 0;

// Turn every output off (used when switching modes)
void silenceAll() {
  ledcWrite(LED_CH, 0);
  ledcWriteTone(BUZZER_CH, 0);
  ledcWrite(SERVO_CH, 0);
}

// Short rising blip so you HEAR the mode change
void modeBeep() {
  ledcWriteTone(BUZZER_CH, 800 + mode * 400);
  delay(70);
  ledcWriteTone(BUZZER_CH, 0);
}

// ---------- Mode 5: the singing buzzer ----------
// A buzzer cannot pronounce words, so every SYLLABLE gets its own note:
//   Sa - meer   Ab - bas   is   the   great - est
// The lyrics print in the Serial Monitor exactly when each note plays (karaoke!)
// and the LED flashes on every note.
#define NOTE_REST 0
#define NOTE_C4   262
#define NOTE_E4   330
#define NOTE_G4   392
#define NOTE_C5   523
#define NOTE_D5   587
#define NOTE_E5   659
#define NOTE_G5   784
#define NOTE_C6   1047

// Duration codes: 2 = half, 4 = quarter, 8 = eighth, negative = dotted (x1.5)
const int songNotes[] = {
  // fanfare
  NOTE_C4, NOTE_E4, NOTE_G4, NOTE_C5, NOTE_REST,
  // verse 1: Sa-meer Ab-bas is the great-est
  NOTE_G4, NOTE_C5, NOTE_E5, NOTE_G5, NOTE_E5, NOTE_D5, NOTE_G5, NOTE_C5, NOTE_REST,
  // verse 2: same tune, bigger finish
  NOTE_G4, NOTE_C5, NOTE_E5, NOTE_G5, NOTE_E5, NOTE_D5, NOTE_G5, NOTE_C6
};
const int songDur[] = {
  8, 8, 8, 2, 4,
  8, -4, 8, -4, 8, 8, 4, 2, 4,
  8, -4, 8, -4, 8, 8, 4, -2
};
const char* songLyrics[] = {
  "[fanfare] ", "", "", "", "\n",
  "Sa-", "meer ", "Ab-", "bas ", "is ", "the ", "great-", "est!", "\n",
  "Sa-", "meer ", "Ab-", "bas ", "is ", "the ", "great-", "EST!!!\n"
};
const int songLength = sizeof(songNotes) / sizeof(songNotes[0]);

void singSong() {
  int wholeNote = (60000 * 4) / 120;               // tempo = 120 BPM
  for (int i = 0; i < songLength; i++) {
    int d = songDur[i];
    int noteTime = (d > 0) ? wholeNote / d : (wholeNote / abs(d)) * 3 / 2;

    Serial.print(songLyrics[i]);                   // show the syllable as it is "sung"

    if (songNotes[i] == NOTE_REST) {
      delay(noteTime);
    } else {
      ledcWriteTone(BUZZER_CH, songNotes[i]);      // sing the note
      ledcWrite(LED_CH, LED_MAX);                  // LED flashes with the note
      delay(noteTime * 9 / 10);
      ledcWriteTone(BUZZER_CH, 0);
      ledcWrite(LED_CH, 0);
      delay(noteTime / 10);                        // tiny gap between notes
    }
  }
  Serial.println("(press the button for the next mode)");
}

// ---------- Button with debounce ----------
void checkButton() {
  int reading = digitalRead(BUTTON_PIN);

  if (reading != lastReading) lastDebounceTime = millis();   // noise or press -> restart timer

  if ((millis() - lastDebounceTime) > DEBOUNCE_MS && reading != buttonState) {
    buttonState = reading;
    if (buttonState == LOW) {                                // pressed
      mode = (mode + 1) % NUM_MODES;
      silenceAll();
      modeBeep();
      Serial.printf("\n=== MODE %d: %s ===\n", mode + 1, modeNames[mode]);
      if (mode == SING) singSong();                          // plays once, then waits
    }
  }
  lastReading = reading;
}

// ---------- Mode 1: breathing LED ----------
// Our eyes judge brightness non-linearly, so a straight duty ramp looks wrong.
// Raising the brightness to the power 2.2 (gamma correction) makes the fade look smooth.
void runBreathing() {
  float t = millis() / 1000.0;
  float brightness = (sin(2 * PI * t / 3.0 - PI / 2) + 1) / 2;   // smooth 0..1 wave, 3 s per breath
  curDuty = (int)(pow(brightness, 2.2) * LED_MAX);
  ledcWrite(LED_CH, curDuty);
  curFreq = LED_FREQ; curBits = LED_RES; curMax = LED_MAX;
}

// ---------- Mode 2: potentiometer dimmer ----------
void runDimmer() {
  int duty = map((int)smoothPot, 0, 4095, 0, LED_MAX);   // 12-bit ADC -> 10-bit PWM
  duty = constrain(duty, 0, LED_MAX);                    // safety net against ADC noise
  ledcWrite(LED_CH, duty);
  curDuty = duty; curFreq = LED_FREQ; curBits = LED_RES; curMax = LED_MAX;
}

// ---------- Mode 3: theremin ----------
void runTheremin() {
  static int lastFreq = 0;
  int freq = map((int)smoothPot, 0, 4095, 200, 2000);    // pot sets the PITCH
  freq = constrain(freq, 200, 2000);
  if (abs(freq - lastFreq) > 3) {                        // only retune when it really changed
    ledcWriteTone(BUZZER_CH, freq);                      // keeps duty at 50%
    lastFreq = freq;
  }
  curFreq = freq; curBits = 10; curDuty = 511; curMax = 1023;   // ~50% duty
}

// ---------- Mode 4: servo ----------
void runServo() {
  curAngle   = constrain(map((int)smoothPot, 0, 4095, 0, 180), 0, 180);
  curPulseUs = map(curAngle, 0, 180, SERVO_MIN_US, SERVO_MAX_US);
  // duty = pulse / period * max value   (period = 20,000 us)
  curDuty = (int)((long)curPulseUs * SERVO_MAX / 20000L);
  ledcWrite(SERVO_CH, curDuty);
  curFreq = SERVO_FREQ; curBits = SERVO_RES; curMax = SERVO_MAX;
}

// ---------- Live PWM dashboard ----------
void printDashboard() {
  if (mode == SING || millis() - lastPrint < 300) return;
  lastPrint = millis();

  float dutyPct = curDuty * 100.0 / curMax;
  Serial.printf("[%-13s] f=%4d Hz | %2d-bit | duty=%5d/%-5d (%5.1f%%) | ",
                modeNames[mode], curFreq, curBits, curDuty, curMax, dutyPct);

  if (mode == SERVO) {
    Serial.printf("pulse=%d us | angle=%d deg\n", curPulseUs, curAngle);
  } else {
    Serial.printf("Vavg = %.2f V\n", dutyPct / 100.0 * 3.3);   // Vavg = Duty x VH
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  ledcSetup(LED_CH, LED_FREQ, LED_RES);
  ledcAttachPin(LED_PIN, LED_CH);

  ledcSetup(BUZZER_CH, 2000, 10);
  ledcAttachPin(BUZZER_PIN, BUZZER_CH);

  ledcSetup(SERVO_CH, SERVO_FREQ, SERVO_RES);
  ledcAttachPin(SERVO_PIN, SERVO_CH);

  smoothPot = analogRead(POT_PIN);

  Serial.println("=== ESP32 PWM SHOWCASE STATION ===");
  Serial.println("Press the button to change mode.");
  Serial.printf("\n=== MODE 1: %s ===\n", modeNames[mode]);
}

void loop() {
  checkButton();

  // Exponential smoothing removes ADC jitter: new = 85% old + 15% fresh reading
  smoothPot = smoothPot * 0.85 + analogRead(POT_PIN) * 0.15;

  switch (mode) {
    case BREATHING: runBreathing(); break;
    case DIMMER:    runDimmer();    break;
    case THEREMIN:  runTheremin();  break;
    case SERVO:     runServo();     break;
    case SING:      break;          // song plays once when you enter this mode
  }

  printDashboard();
  delay(10);
}